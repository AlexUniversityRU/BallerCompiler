package com.company;

import javax.jws.soap.SOAPMessageHandlers;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Lexer {


    public ArrayList<Token> nextToken() throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        String s;
        String input = "";
        ArrayList<Token> tokens = new ArrayList<Token>();

        // There is probably a smarter way to read the line than this
        while ((s = in.readLine()) != null && s.length() != 0) {
            input = s;
        }

        // Just testing grabbing patterns with regex
        String NUMBER = "^[1-9]+[0-9]*";
        String test = "\\w+";
        Pattern pattern = Pattern.compile(NUMBER);
        Matcher matcher = pattern.matcher(input);
        while(matcher.find()){
            System.out.print("Start index: " + matcher.start());
            System.out.print(" End index: " + matcher.end() + " ");
            System.out.println(matcher.group());
        }

        return tokens;
    }
}



